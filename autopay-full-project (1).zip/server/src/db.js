const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const dataDir = path.join(__dirname, '../../data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const db = new Database(path.join(dataDir, 'autopay.db'));
db.pragma('journal_mode = WAL');

// Initialize database schema
db.exec(`
  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
  );

  CREATE TABLE IF NOT EXISTS payment_methods (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT NOT NULL, -- personal, merchant, agent
    number TEXT NOT NULL,
    charge_percentage REAL DEFAULT 0,
    min_amount REAL DEFAULT 10,
    max_amount REAL DEFAULT 25000,
    is_active INTEGER DEFAULT 1,
    instructions TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    invoice_id TEXT UNIQUE NOT NULL,
    customer_name TEXT,
    customer_phone TEXT,
    customer_email TEXT,
    amount REAL NOT NULL,
    charge REAL DEFAULT 0,
    total_amount REAL NOT NULL,
    method TEXT, -- bKash, Nagad, Rocket, Upay
    receiver_number TEXT,
    trx_id TEXT,
    status TEXT DEFAULT 'PENDING', -- PENDING, COMPLETED, FAILED, EXPIRED
    callback_url TEXT,
    redirect_url TEXT,
    metadata TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    verified_at DATETIME,
    expires_at DATETIME
  );

  CREATE TABLE IF NOT EXISTS reader_devices (
    id TEXT PRIMARY KEY,
    device_name TEXT NOT NULL,
    device_model TEXT,
    pairing_key TEXT UNIQUE NOT NULL,
    status TEXT DEFAULT 'ONLINE',
    last_synced_at DATETIME,
    battery_level INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS sms_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender TEXT NOT NULL,
    body TEXT NOT NULL,
    method TEXT,
    trx_id TEXT,
    amount REAL,
    counter_phone TEXT,
    raw_timestamp TEXT,
    device_id TEXT,
    matched_transaction_id TEXT,
    status TEXT DEFAULT 'PROCESSED', -- PROCESSED, UNMATCHED, DUPLICATE
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS api_keys (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    public_key TEXT UNIQUE NOT NULL,
    secret_key TEXT UNIQUE NOT NULL,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

// Insert default data if not present
const seedMethods = db.prepare('SELECT COUNT(*) as count FROM payment_methods').get();
if (seedMethods.count === 0) {
  const insertMethod = db.prepare(`
    INSERT INTO payment_methods (id, name, type, number, charge_percentage, min_amount, max_amount, is_active, instructions)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  insertMethod.run('bkash', 'bKash', 'personal', '01700000000', 1.85, 10, 25000, 1, 'Send Money to Personal bKash number with Reference: Invoice ID');
  insertMethod.run('nagad', 'Nagad', 'personal', '01800000000', 1.45, 10, 25000, 1, 'Send Money to Personal Nagad number with Reference: Invoice ID');
  insertMethod.run('rocket', 'Rocket', 'personal', '019000000008', 1.80, 10, 25000, 1, 'Send Money to Personal Rocket number (12 digits)');
  insertMethod.run('upay', 'Upay', 'personal', '01600000000', 1.40, 10, 25000, 1, 'Send Money to Personal Upay number');
}

// Seed default Admin & API keys
const seedKeys = db.prepare('SELECT COUNT(*) as count FROM api_keys').get();
if (seedKeys.count === 0) {
  db.prepare(`
    INSERT INTO api_keys (id, name, public_key, secret_key, is_active)
    VALUES ('default_merchant', 'Default Merchant Store', 'pk_live_bdpay98234710', 'sk_live_sec_bd982347104812', 1)
  `).run();
}

// Default settings
const seedSettings = db.prepare('SELECT COUNT(*) as count FROM settings').get();
if (seedSettings.count === 0) {
  const insertSetting = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?)');
  insertSetting.run('site_name', 'BD AutoPay Gateway');
  insertSetting.run('admin_pin', '123456');
  insertSetting.run('merchant_email', 'admin@paybd.com');
  insertSetting.run('pairing_key', 'READER-AUTO-9988');
  insertSetting.run('plan_name', 'Enterprise Auto-Sync Plan');
  insertSetting.run('webhook_url', 'http://localhost:3000/api/v1/webhook/sample');
} else {
  // Ensure merchant_email exists
  const existingEmail = db.prepare("SELECT value FROM settings WHERE key = 'merchant_email'").get();
  if (!existingEmail) {
    db.prepare("INSERT INTO settings (key, value) VALUES ('merchant_email', 'admin@paybd.com')").run();
  }
}

module.exports = db;
