const express = require('express');
const cors = require('cors');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const db = require('./db');
const { parseMfsMessage } = require('./smsParser');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../../public')));

// Helpers
function getSettings() {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  return rows.reduce((acc, row) => ({ ...acc, [row.key]: row.value }), {});
}

// ==========================================
// 1. PUBLIC CHECKOUT & PAYMENT FLOW APIS
// ==========================================

// Create a new checkout transaction / invoice
app.post('/api/v1/checkout/create', (req, res) => {
  try {
    const {
      amount,
      customer_name,
      customer_phone,
      customer_email,
      redirect_url,
      callback_url,
      metadata
    } = req.body;

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      return res.status(400).json({ status: false, message: 'Invalid payment amount' });
    }

    const invoiceId = 'INV-' + Math.floor(100000 + Math.random() * 900000);
    const id = uuidv4();
    const expiresAt = new Date(Date.now() + 20 * 60 * 1000).toISOString(); // 20 minutes expiration

    db.prepare(`
      INSERT INTO transactions (
        id, invoice_id, customer_name, customer_phone, customer_email,
        amount, charge, total_amount, status, redirect_url, callback_url, metadata, expires_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', ?, ?, ?, ?)
    `).run(
      id,
      invoiceId,
      customer_name || 'Customer',
      customer_phone || '',
      customer_email || '',
      parsedAmount,
      0,
      parsedAmount,
      redirect_url || '',
      callback_url || '',
      typeof metadata === 'object' ? JSON.stringify(metadata) : metadata || '',
      expiresAt
    );

    const paymentUrl = `/checkout.html?invoice=${invoiceId}`;

    res.json({
      status: true,
      message: 'Checkout initialized successfully',
      invoice_id: invoiceId,
      payment_url: paymentUrl,
      amount: parsedAmount
    });
  } catch (err) {
    res.status(500).json({ status: false, error: err.message });
  }
});

// Fetch checkout details by Invoice ID or Transaction ID
app.get('/api/v1/checkout/:identifier', (req, res) => {
  const { identifier } = req.params;
  const transaction = db.prepare(`
    SELECT * FROM transactions WHERE invoice_id = ? OR id = ?
  `).get(identifier, identifier);

  if (!transaction) {
    return res.status(404).json({ status: false, message: 'Invoice not found' });
  }

  const methods = db.prepare('SELECT * FROM payment_methods WHERE is_active = 1').all();

  res.json({
    status: true,
    data: {
      ...transaction,
      methods
    }
  });
});

// Submit TrxID for verification by customer
app.post('/api/v1/checkout/:invoiceId/verify', (req, res) => {
  try {
    const { invoiceId } = req.params;
    let { trx_id, method } = req.body;

    if (!trx_id) {
      return res.status(400).json({ status: false, message: 'Transaction ID is required' });
    }

    trx_id = trx_id.trim().toUpperCase();

    const transaction = db.prepare('SELECT * FROM transactions WHERE invoice_id = ?').get(invoiceId);
    if (!transaction) {
      return res.status(404).json({ status: false, message: 'Invoice not found' });
    }

    if (transaction.status === 'COMPLETED') {
      return res.json({
        status: true,
        message: 'Payment already completed successfully!',
        transaction
      });
    }

    // Check if this TrxID has already been received from reader app SMS logs
    const matchingSms = db.prepare(`
      SELECT * FROM sms_logs 
      WHERE UPPER(trx_id) = ? AND (matched_transaction_id IS NULL OR matched_transaction_id = ?)
      ORDER BY id DESC LIMIT 1
    `).get(trx_id, transaction.id);

    if (matchingSms) {
      // Auto verify!
      db.prepare(`
        UPDATE transactions 
        SET status = 'COMPLETED', method = ?, trx_id = ?, verified_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(matchingSms.method || method || 'bKash', trx_id, transaction.id);

      db.prepare(`
        UPDATE sms_logs 
        SET matched_transaction_id = ?, status = 'PROCESSED' 
        WHERE id = ?
      `).run(transaction.id, matchingSms.id);

      const updated = db.prepare('SELECT * FROM transactions WHERE id = ?').get(transaction.id);

      return res.json({
        status: true,
        verified: true,
        message: 'Payment verified successfully by automated reader!',
        transaction: updated
      });
    }

    // If reader hasn't received SMS yet or manual mode, update transaction with submitted TrxID
    db.prepare(`
      UPDATE transactions 
      SET trx_id = ?, method = ?
      WHERE id = ?
    `).run(trx_id, method || 'bKash', transaction.id);

    const current = db.prepare('SELECT * FROM transactions WHERE id = ?').get(transaction.id);

    res.json({
      status: true,
      verified: false,
      message: 'Transaction ID recorded. Verifying with mobile gateway...',
      transaction: current
    });
  } catch (err) {
    res.status(500).json({ status: false, error: err.message });
  }
});

// ==========================================
// 2. ANDROID READER DEVICE SYNC APIS
// ==========================================

// Pair reader device using Merchant Email & Device Key (Pairing Key)
app.post('/api/v1/reader/pair', (req, res) => {
  try {
    const { email, pairing_key, device_key, device_name, device_model, battery_level } = req.body;
    const settings = getSettings();

    const providedKey = (device_key || pairing_key || '').trim().toUpperCase();
    const serverKey = (settings.pairing_key || '').trim().toUpperCase();
    const serverEmail = (settings.merchant_email || 'admin@paybd.com').trim().toLowerCase();

    // Check device key / pairing key
    if (!providedKey || providedKey !== serverKey) {
      return res.status(401).json({ 
        status: false, 
        message: 'ভুল ডিভাইস কী (Invalid Device Key)! অনুগ্রহ করে অ্যাডমিন প্যানেল থেকে সঠিক ডিভাইস কী দিন।' 
      });
    }

    // If merchant email is provided, validate email as well
    if (email && email.trim()) {
      const inputEmail = email.trim().toLowerCase();
      if (inputEmail !== serverEmail) {
        return res.status(401).json({
          status: false,
          message: `ইমেইল মিলছে না! অ্যাডমিন প্যানেলে নিবন্ধিত ইমেইল (${serverEmail}) ব্যবহার করুন।`
        });
      }
    }

    const deviceId = 'DEV-' + Math.floor(1000 + Math.random() * 9000);
    db.prepare(`
      INSERT OR REPLACE INTO reader_devices (id, device_name, device_model, pairing_key, status, last_synced_at, battery_level)
      VALUES (?, ?, ?, ?, 'ONLINE', CURRENT_TIMESTAMP, ?)
    `).run(deviceId, device_name || 'Android Reader', device_model || 'Android Phone', providedKey, battery_level || 100);

    res.json({
      status: true,
      message: 'ডিভাইস সফলভাবে সার্ভারের সাথে কানেক্ট হয়েছে (Paired Successfully)!',
      device_id: deviceId,
      merchant_email: serverEmail
    });
  } catch (err) {
    res.status(500).json({ status: false, error: err.message });
  }
});

// Sync SMS from Android Reader App
app.post('/api/v1/reader/sync-sms', (req, res) => {
  try {
    const { device_id, sender, body, timestamp } = req.body;

    if (!body || !sender) {
      return res.status(400).json({ status: false, message: 'Sender and Body are required' });
    }

    // Update device active state
    if (device_id) {
      db.prepare(`
        UPDATE reader_devices 
        SET last_synced_at = CURRENT_TIMESTAMP, status = 'ONLINE' 
        WHERE id = ?
      `).run(device_id);
    }

    // Parse the SMS text
    const parsed = parseMfsMessage(sender, body);

    if (!parsed || !parsed.trxId) {
      // Record unparsed SMS log for monitoring
      db.prepare(`
        INSERT INTO sms_logs (sender, body, raw_timestamp, device_id, status)
        VALUES (?, ?, ?, ?, 'UNMATCHED')
      `).run(sender, body, timestamp || new Date().toISOString(), device_id || null);

      return res.json({
        status: true,
        parsed: false,
        message: 'SMS received but no transaction ID identified'
      });
    }

    // Check if TrxID already recorded
    const existingLog = db.prepare('SELECT id, matched_transaction_id FROM sms_logs WHERE trx_id = ?').get(parsed.trxId);
    let logId;
    if (existingLog) {
      logId = existingLog.id;
    } else {
      const result = db.prepare(`
        INSERT INTO sms_logs (sender, body, method, trx_id, amount, counter_phone, raw_timestamp, device_id, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PROCESSED')
      `).run(sender, body, parsed.method, parsed.trxId, parsed.amount, parsed.senderNumber, timestamp || new Date().toISOString(), device_id || null);
      logId = result.lastInsertRowid;
    }

    // Check if any PENDING transaction matches this TrxID or has this TrxID submitted
    const pendingTx = db.prepare(`
      SELECT * FROM transactions 
      WHERE (UPPER(trx_id) = ? OR (status = 'PENDING' AND amount <= ? AND trx_id = ?))
      ORDER BY id DESC LIMIT 1
    `).get(parsed.trxId, parsed.amount + 2, parsed.trxId);

    if (pendingTx && pendingTx.status !== 'COMPLETED') {
      db.prepare(`
        UPDATE transactions 
        SET status = 'COMPLETED', method = ?, trx_id = ?, verified_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(parsed.method, parsed.trxId, pendingTx.id);

      db.prepare(`
        UPDATE sms_logs 
        SET matched_transaction_id = ? 
        WHERE id = ?
      `).run(pendingTx.id, logId);

      return res.json({
        status: true,
        parsed: true,
        matched: true,
        trx_id: parsed.trxId,
        invoice_id: pendingTx.invoice_id,
        message: `Payment for invoice ${pendingTx.invoice_id} auto-completed!`
      });
    }

    res.json({
      status: true,
      parsed: true,
      matched: false,
      trx_id: parsed.trxId,
      amount: parsed.amount,
      method: parsed.method,
      message: 'Payment received & stored in pool. Waiting for invoice match.'
    });
  } catch (err) {
    res.status(500).json({ status: false, error: err.message });
  }
});

// Device status heartbeat
app.get('/api/v1/reader/status', (req, res) => {
  const devices = db.prepare('SELECT * FROM reader_devices ORDER BY last_synced_at DESC').all();
  const settings = getSettings();
  res.json({
    status: true,
    server_time: new Date().toISOString(),
    pairing_key: settings.pairing_key,
    devices
  });
});

// ==========================================
// 3. ADMIN & MERCHANT DASHBOARD APIS
// ==========================================

// Dashboard stats
app.get('/api/v1/admin/overview', (req, res) => {
  try {
    const totalTransactions = db.prepare('SELECT COUNT(*) as count FROM transactions').get().count;
    const completedTransactions = db.prepare("SELECT COUNT(*) as count FROM transactions WHERE status = 'COMPLETED'").get().count;
    const totalVolume = db.prepare("SELECT COALESCE(SUM(amount), 0) as sum FROM transactions WHERE status = 'COMPLETED'").get().sum;
    const todayVolume = db.prepare("SELECT COALESCE(SUM(amount), 0) as sum FROM transactions WHERE status = 'COMPLETED' AND date(created_at) = date('now')").get().sum;
    const pendingTransactions = db.prepare("SELECT COUNT(*) as count FROM transactions WHERE status = 'PENDING'").get().count;
    const activeDevices = db.prepare("SELECT COUNT(*) as count FROM reader_devices WHERE status = 'ONLINE'").get().count;

    const recentTransactions = db.prepare(`
      SELECT * FROM transactions ORDER BY created_at DESC LIMIT 10
    `).all();

    const recentSms = db.prepare(`
      SELECT * FROM sms_logs ORDER BY created_at DESC LIMIT 10
    `).all();

    res.json({
      status: true,
      stats: {
        totalVolume,
        todayVolume,
        totalTransactions,
        completedTransactions,
        pendingTransactions,
        activeDevices
      },
      recentTransactions,
      recentSms
    });
  } catch (err) {
    res.status(500).json({ status: false, error: err.message });
  }
});

// All Transactions
app.get('/api/v1/admin/transactions', (req, res) => {
  const { status, search } = req.query;
  let query = 'SELECT * FROM transactions WHERE 1=1';
  const params = [];

  if (status) {
    query += ' AND status = ?';
    params.push(status);
  }
  if (search) {
    query += ' AND (invoice_id LIKE ? OR trx_id LIKE ? OR customer_phone LIKE ?)';
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }

  query += ' ORDER BY created_at DESC';
  const list = db.prepare(query).all(...params);
  res.json({ status: true, transactions: list });
});

// Manual status update by Admin
app.post('/api/v1/admin/transactions/:id/action', (req, res) => {
  try {
    const { id } = req.params;
    const { action } = req.body; // 'APPROVE', 'REJECT'

    const tx = db.prepare('SELECT * FROM transactions WHERE id = ?').get(id);
    if (!tx) {
      return res.status(404).json({ status: false, message: 'Transaction not found' });
    }

    if (action === 'APPROVE') {
      db.prepare(`
        UPDATE transactions 
        SET status = 'COMPLETED', verified_at = CURRENT_TIMESTAMP 
        WHERE id = ?
      `).run(id);
    } else if (action === 'REJECT') {
      db.prepare(`
        UPDATE transactions 
        SET status = 'FAILED' 
        WHERE id = ?
      `).run(id);
    }

    res.json({ status: true, message: `Transaction marked as ${action}` });
  } catch (err) {
    res.status(500).json({ status: false, error: err.message });
  }
});

// Payment Methods API
app.get('/api/v1/admin/payment-methods', (req, res) => {
  const methods = db.prepare('SELECT * FROM payment_methods').all();
  res.json({ status: true, methods });
});

app.post('/api/v1/admin/payment-methods/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { number, type, charge_percentage, is_active, instructions } = req.body;

    db.prepare(`
      UPDATE payment_methods 
      SET number = ?, type = ?, charge_percentage = ?, is_active = ?, instructions = ?
      WHERE id = ?
    `).run(number, type, charge_percentage, is_active ? 1 : 0, instructions, id);

    res.json({ status: true, message: 'Payment method updated successfully' });
  } catch (err) {
    res.status(500).json({ status: false, error: err.message });
  }
});

// Settings API
app.get('/api/v1/admin/settings', (req, res) => {
  res.json({ status: true, settings: getSettings() });
});

app.post('/api/v1/admin/settings', (req, res) => {
  try {
    const updates = req.body;
    for (const [key, val] of Object.entries(updates)) {
      db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').run(key, String(val));
    }
    res.json({ status: true, message: 'Settings saved successfully' });
  } catch (err) {
    res.status(500).json({ status: false, error: err.message });
  }
});

// Health check
app.get('/api/v1/health', (req, res) => {
  res.json({ status: true, service: 'BD AutoPay Gateway Server', time: new Date().toISOString() });
});

if (require.main === module) {
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 BD AutoPay Gateway running on http://0.0.0.0:${PORT}`);
  });
}

module.exports = app;
