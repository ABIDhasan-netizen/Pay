/**
 * Parser for Bangladeshi Mobile Financial Services (MFS) SMS & Notification messages.
 * Supported providers: bKash, Nagad, Rocket, Upay.
 */

function parseMfsMessage(sender, text) {
  if (!text) return null;
  const cleanSender = (sender || '').toUpperCase();
  const cleanText = text.replace(/\r?\n/g, ' ').trim();

  let method = null;
  if (cleanSender.includes('BKASH') || cleanSender.includes('16247') || /bkash/i.test(cleanText)) {
    method = 'bKash';
  } else if (cleanSender.includes('ROCKET') || cleanSender.includes('16216') || cleanSender.includes('DBBL') || /rocket/i.test(cleanText)) {
    method = 'Rocket';
  } else if (cleanSender.includes('NAGAD') || cleanSender.includes('16167') || /nagad/i.test(cleanText)) {
    method = 'Nagad';
  } else if (cleanSender.includes('UPAY') || /upay/i.test(cleanText)) {
    method = 'Upay';
  }

  // 1. bKash parsing:
  // "You have received Tk 500.00 from 017xxxxxxxx. Fee Tk 0.00. Balance Tk ... TrxID 9K48SJDJ23 at 01/01/2026 12:00"
  // "You have received payment Tk 1,200.00 from 018... TrxID 8K12X990..."
  if (method === 'bKash' || /TrxID\s*[:]?\s*([A-Za-z0-9]+)/i.test(cleanText)) {
    const trxMatch = cleanText.match(/TrxID\s*[:]?\s*([A-Za-z0-9]+)/i);
    const amountMatch = cleanText.match(/(?:Tk|BDT|amount)\s*[:]?\s*([0-9,]+(?:\.[0-9]{1,2})?)/i);
    const senderMatch = cleanText.match(/from\s+([0-9+]+)/i);

    if (trxMatch) {
      return {
        method: method || 'bKash',
        trxId: trxMatch[1].toUpperCase(),
        amount: amountMatch ? parseFloat(amountMatch[1].replace(/,/g, '')) : 0,
        senderNumber: senderMatch ? senderMatch[1] : null,
        raw: cleanText,
        type: 'RECEIVED'
      };
    }
  }

  // 2. Rocket parsing (DBBL 16216):
  // "Tk 500.00 received from 017xxxxxxxx8 for A/C ... TxnId: 1987483723 Date:..."
  if (method === 'Rocket') {
    const txnMatch = cleanText.match(/(?:TxnId|TxnID|TrxID)\s*[:]?\s*([0-9A-Za-z]+)/i);
    const amountMatch = cleanText.match(/(?:Tk\s*|BDT\s*)([0-9,]+(?:\.[0-9]{1,2})?)/i);
    const senderMatch = cleanText.match(/from\s+([0-9+]+)/i);

    if (txnMatch) {
      return {
        method: 'Rocket',
        trxId: txnMatch[1].toUpperCase(),
        amount: amountMatch ? parseFloat(amountMatch[1].replace(/,/g, '')) : 0,
        senderNumber: senderMatch ? senderMatch[1] : null,
        raw: cleanText,
        type: 'RECEIVED'
      };
    }
  }

  // 3. Nagad parsing (16167):
  // "Money Received Amount: Tk 500.00 Sender: 017xxxxxxxx TxnID: 712J9H98 Date: ..."
  if (method === 'Nagad' || /TxnID\s*[:]?\s*([A-Za-z0-9]+)/i.test(cleanText)) {
    const txnMatch = cleanText.match(/TxnID\s*[:]?\s*([A-Za-z0-9]+)/i);
    const amountMatch = cleanText.match(/Amount\s*[:]?\s*(?:Tk\s*)?([0-9,]+(?:\.[0-9]{1,2})?)/i) ||
                        cleanText.match(/(?:Tk|BDT)\s*([0-9,]+(?:\.[0-9]{1,2})?)/i);
    const senderMatch = cleanText.match(/Sender\s*[:]?\s*([0-9+]+)/i) || cleanText.match(/from\s+([0-9+]+)/i);

    if (txnMatch) {
      return {
        method: 'Nagad',
        trxId: txnMatch[1].toUpperCase(),
        amount: amountMatch ? parseFloat(amountMatch[1].replace(/,/g, '')) : 0,
        senderNumber: senderMatch ? senderMatch[1] : null,
        raw: cleanText,
        type: 'RECEIVED'
      };
    }
  }

  // 4. Fallback generic MFS:
  const genericTxn = cleanText.match(/(?:TrxID|TxnID|TxnId|Txn\s*ID|Transaction\s*ID)\s*[:]?\s*([0-9A-Za-z]+)/i);
  const genericAmount = cleanText.match(/(?:Tk|BDT)\s*[:]?\s*([0-9,]+(?:\.[0-9]{1,2})?)/i);
  const genericSender = cleanText.match(/from\s+([0-9+]+)/i);

  if (genericTxn) {
    return {
      method: method || 'bKash',
      trxId: genericTxn[1].toUpperCase(),
      amount: genericAmount ? parseFloat(genericAmount[1].replace(/,/g, '')) : 0,
      senderNumber: genericSender ? genericSender[1] : null,
      raw: cleanText,
      type: 'RECEIVED'
    };
  }

  return null;
}

module.exports = {
  parseMfsMessage
};
