const test = require('node:test');
const assert = require('node:assert');
const app = require('../src/server');
const http = require('http');

let server;
let baseUrl;

test.before((t, done) => {
  server = http.createServer(app);
  server.listen(0, () => {
    const port = server.address().port;
    baseUrl = `http://127.0.0.1:${port}`;
    done();
  });
});

test.after((t, done) => {
  server.close(done);
});

test('Full Auto Payment Flow: Create Invoice -> Reader Sync SMS -> Auto Verify', async () => {
  // 1. Create Checkout Invoice
  const createRes = await fetch(`${baseUrl}/api/v1/checkout/create`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      amount: 450,
      customer_name: 'Test Customer',
      customer_phone: '01711223344'
    })
  });
  const createData = await createRes.json();
  assert.strictEqual(createData.status, true);
  const invoiceId = createData.invoice_id;
  assert.ok(invoiceId);

  // 2. Fetch Invoice
  const getRes = await fetch(`${baseUrl}/api/v1/checkout/${invoiceId}`);
  const getData = await getRes.json();
  assert.strictEqual(getData.status, true);
  assert.strictEqual(getData.data.status, 'PENDING');
  assert.strictEqual(getData.data.amount, 450);

  // 3. Customer submits TrxID
  const sampleTrx = 'TESTTRX' + Math.floor(100000 + Math.random() * 900000);
  const verifyRes = await fetch(`${baseUrl}/api/v1/checkout/${invoiceId}/verify`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      trx_id: sampleTrx,
      method: 'bKash'
    })
  });
  const verifyData = await verifyRes.json();
  assert.strictEqual(verifyData.status, true);
  assert.strictEqual(verifyData.verified, false); // Pending SMS sync

  // 4. Android Reader syncs SMS with matching TrxID
  const syncRes = await fetch(`${baseUrl}/api/v1/reader/sync-sms`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      device_id: 'DEV-TEST-01',
      sender: 'bKash',
      body: `You have received Tk 450.00 from 01711223344. Fee Tk 0.00. Balance Tk 5000. TrxID ${sampleTrx} at 02/03/2026 12:00`,
      timestamp: new Date().toISOString()
    })
  });
  const syncData = await syncRes.json();
  assert.strictEqual(syncData.status, true);
  assert.strictEqual(syncData.matched, true);
  assert.strictEqual(syncData.invoice_id, invoiceId);

  // 5. Verify Invoice status is now COMPLETED
  const finalRes = await fetch(`${baseUrl}/api/v1/checkout/${invoiceId}`);
  const finalData = await finalRes.json();
  assert.strictEqual(finalData.status, true);
  assert.strictEqual(finalData.data.status, 'COMPLETED');
  assert.strictEqual(finalData.data.trx_id, sampleTrx);
});

test('Reader Pairing API works with correct pairing key', async () => {
  const pairRes = await fetch(`${baseUrl}/api/v1/reader/pair`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      pairing_key: 'READER-AUTO-9988',
      device_name: 'Test Device',
      device_model: 'Pixel 7',
      battery_level: 90
    })
  });
  const pairData = await pairRes.json();
  assert.strictEqual(pairData.status, true);
  assert.ok(pairData.device_id);
});

test('Admin overview API returns accurate statistics', async () => {
  const adminRes = await fetch(`${baseUrl}/api/v1/admin/overview`);
  const adminData = await adminRes.json();
  assert.strictEqual(adminData.status, true);
  assert.ok(adminData.stats);
  assert.ok(adminData.stats.totalTransactions >= 1);
});
