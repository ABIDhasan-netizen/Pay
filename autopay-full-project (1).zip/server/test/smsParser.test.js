const test = require('node:test');
const assert = require('node:assert');
const { parseMfsMessage } = require('../src/smsParser');

test('bKash SMS Parser extracts TrxID and Amount accurately', () => {
  const bkashSms = "You have received Tk 1,500.00 from 01712345678. Fee Tk 0.00. Balance Tk 15,240.50. TrxID BLK79A4X98 at 02/03/2026 14:32";
  const parsed = parseMfsMessage('bKash', bkashSms);

  assert.ok(parsed);
  assert.strictEqual(parsed.method, 'bKash');
  assert.strictEqual(parsed.trxId, 'BLK79A4X98');
  assert.strictEqual(parsed.amount, 1500.00);
  assert.strictEqual(parsed.senderNumber, '01712345678');
});

test('Nagad SMS Parser extracts TxnID and Amount accurately', () => {
  const nagadSms = "Money Received Amount: Tk 750.00 Sender: 01823456789 TxnID: 72N6K9Q4 Date: 2026-03-02 15:10:22";
  const parsed = parseMfsMessage('Nagad', nagadSms);

  assert.ok(parsed);
  assert.strictEqual(parsed.method, 'Nagad');
  assert.strictEqual(parsed.trxId, '72N6K9Q4');
  assert.strictEqual(parsed.amount, 750.00);
  assert.strictEqual(parsed.senderNumber, '01823456789');
});

test('Rocket SMS Parser extracts TxnId and Amount accurately', () => {
  const rocketSms = "Tk 320.00 received from 019876543210 for A/C ... TxnId: 88921471 Date: 2026-03-02 16:00";
  const parsed = parseMfsMessage('16216', rocketSms);

  assert.ok(parsed);
  assert.strictEqual(parsed.method, 'Rocket');
  assert.strictEqual(parsed.trxId, '88921471');
  assert.strictEqual(parsed.amount, 320.00);
});
