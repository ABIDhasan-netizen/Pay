document.addEventListener('DOMContentLoaded', () => {
  feather.replace();
  setupNav();
  loadOverview();
  loadPaymentMethods();
  loadDevices();

  document.getElementById('createLinkForm').addEventListener('submit', handleCreateLink);
  document.getElementById('simulatorForm').addEventListener('submit', handleSimulatorSubmit);
});

function setupNav() {
  const menuItems = document.querySelectorAll('.menu-item');
  menuItems.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      menuItems.forEach(m => m.classList.remove('active'));
      item.classList.add('active');

      const targetTab = item.dataset.tab;
      document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
      const activePane = document.getElementById(`tab-${targetTab}`);
      if (activePane) activePane.classList.add('active');

      document.getElementById('currentTabTitle').textContent = item.textContent.trim();

      if (targetTab === 'transactions') loadAllTransactions();
      if (targetTab === 'methods') loadPaymentMethods();
      if (targetTab === 'devices') loadDevices();
      if (targetTab === 'overview') loadOverview();

      feather.replace();
    });
  });
}

async function loadOverview() {
  try {
    const res = await fetch('/api/v1/admin/overview');
    const data = await res.json();
    if (!data.status) return;

    document.getElementById('statTotalVolume').textContent = `৳ ${data.stats.totalVolume.toFixed(2)}`;
    document.getElementById('statTodayVolume').textContent = `৳ ${data.stats.todayVolume.toFixed(2)}`;
    document.getElementById('statCompletedTx').textContent = data.stats.completedTransactions;
    document.getElementById('statActiveDevices').textContent = data.stats.activeDevices;

    // Render Recent Transactions
    const txTbody = document.getElementById('recentTransactionsTable');
    if (data.recentTransactions.length === 0) {
      txTbody.innerHTML = '<tr><td colspan="7" class="text-center">কোনো ট্রানজেকশন পাওয়া যায়নি</td></tr>';
    } else {
      txTbody.innerHTML = data.recentTransactions.map(t => `
        <tr>
          <td><strong>${t.invoice_id}</strong></td>
          <td>${t.customer_name || 'Anonymous'}</td>
          <td>৳ ${t.amount.toFixed(2)}</td>
          <td><span class="badge">${t.method || 'N/A'}</span></td>
          <td><code>${t.trx_id || 'PENDING'}</code></td>
          <td><span class="badge badge-${t.status.toLowerCase()}">${t.status}</span></td>
          <td><small>${new Date(t.created_at).toLocaleTimeString()}</small></td>
        </tr>
      `).join('');
    }

    // Render Recent SMS
    const smsTbody = document.getElementById('recentSmsTable');
    if (data.recentSms.length === 0) {
      smsTbody.innerHTML = '<tr><td colspan="6" class="text-center">রিডার অ্যাপ থেকে এখনও এসএমএস আসেনি</td></tr>';
    } else {
      smsTbody.innerHTML = data.recentSms.map(s => `
        <tr>
          <td><strong>${s.sender}</strong></td>
          <td><small>${s.body}</small></td>
          <td>${s.method || 'MFS'}</td>
          <td><code>${s.trx_id || 'N/A'}</code></td>
          <td>৳ ${(s.amount || 0).toFixed(2)}</td>
          <td><span class="badge badge-${(s.status || 'PROCESSED').toLowerCase()}">${s.status || 'PROCESSED'}</span></td>
        </tr>
      `).join('');
    }

    feather.replace();
  } catch (err) {
    console.error('Failed to load overview:', err);
  }
}

async function loadAllTransactions() {
  try {
    const search = document.getElementById('txSearch')?.value || '';
    const status = document.getElementById('txFilterStatus')?.value || '';

    const res = await fetch(`/api/v1/admin/transactions?search=${encodeURIComponent(search)}&status=${encodeURIComponent(status)}`);
    const data = await res.json();
    const tbody = document.getElementById('allTransactionsTable');

    if (!data.transactions || data.transactions.length === 0) {
      tbody.innerHTML = '<tr><td colspan="7" class="text-center">কোনো ট্রানজেকশন মেলেনি</td></tr>';
      return;
    }

    tbody.innerHTML = data.transactions.map(t => `
      <tr>
        <td><strong>${t.invoice_id}</strong></td>
        <td>${t.customer_name || 'N/A'} (${t.customer_phone || '-'})</td>
        <td>৳ ${t.amount.toFixed(2)}</td>
        <td>${t.method || 'Pending'}</td>
        <td><code>${t.trx_id || '-'}</code></td>
        <td><span class="badge badge-${t.status.toLowerCase()}">${t.status}</span></td>
        <td>
          ${t.status === 'PENDING' ? `
            <button class="btn btn-sm btn-success" onclick="updateTxStatus('${t.id}', 'APPROVE')">অনুমোদন</button>
            <button class="btn btn-sm btn-secondary" onclick="updateTxStatus('${t.id}', 'REJECT')">বাতিল</button>
          ` : `<small class="text-muted">লকড</small>`}
        </td>
      </tr>
    `).join('');

    feather.replace();
  } catch (err) {
    console.error('Failed to load transactions:', err);
  }
}

async function updateTxStatus(id, action) {
  if (!confirm(`আপনি কি এই ট্রানজেকশনটি ${action} করতে নিশ্চিত?`)) return;
  try {
    const res = await fetch(`/api/v1/admin/transactions/${id}/action`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action })
    });
    const result = await res.json();
    if (result.status) {
      loadAllTransactions();
      loadOverview();
    }
  } catch (e) {
    alert('অ্যাকশন সম্পন্ন করা যায়নি');
  }
}

async function loadPaymentMethods() {
  try {
    const res = await fetch('/api/v1/admin/payment-methods');
    const data = await res.json();
    const container = document.getElementById('methodsList');

    if (!data.methods) return;

    container.innerHTML = data.methods.map(m => `
      <div class="method-config-row">
        <div class="m-brand">${m.name}</div>
        <div class="m-inputs">
          <input type="text" id="m_num_${m.id}" value="${m.number}" placeholder="নম্বর" class="input-control">
          <select id="m_type_${m.id}" class="input-control" style="width: 140px;">
            <option value="personal" ${m.type === 'personal' ? 'selected' : ''}>Personal</option>
            <option value="merchant" ${m.type === 'merchant' ? 'selected' : ''}>Merchant</option>
            <option value="agent" ${m.type === 'agent' ? 'selected' : ''}>Agent</option>
          </select>
          <input type="number" step="0.01" id="m_charge_${m.id}" value="${m.charge_percentage}" placeholder="চার্জ %" class="input-control" style="width: 100px;">
        </div>
        <div>
          <button class="btn btn-primary btn-sm" onclick="saveMethod('${m.id}')">সংরক্ষণ</button>
        </div>
      </div>
    `).join('');
  } catch (e) {
    console.error(e);
  }
}

async function saveMethod(id) {
  const number = document.getElementById(`m_num_${id}`).value;
  const type = document.getElementById(`m_type_${id}`).value;
  const charge = document.getElementById(`m_charge_${id}`).value;

  try {
    const res = await fetch(`/api/v1/admin/payment-methods/${id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ number, type, charge_percentage: parseFloat(charge), is_active: 1 })
    });
    const result = await res.json();
    if (result.status) alert('পেমেন্ট মেথড আপডেট সফল হয়েছে!');
  } catch (e) {
    alert('আপডেট করা যায়নি');
  }
}

async function loadDevices() {
  try {
    const res = await fetch('/api/v1/reader/status');
    const data = await res.json();
    if (data.pairing_key) {
      document.getElementById('displayPairingKey').textContent = data.pairing_key;
    }

    // Also fetch settings to get merchant email
    try {
      const setRes = await fetch('/api/v1/admin/settings');
      const setData = await setRes.json();
      if (setData.status && setData.settings && setData.settings.merchant_email) {
        const emailEl = document.getElementById('displayMerchantEmail');
        if (emailEl) emailEl.textContent = setData.settings.merchant_email;
      }
    } catch (_) {}

    const tbody = document.getElementById('devicesTable');
    if (!data.devices || data.devices.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" class="text-center">কোনো ডিভাইস সংযুক্ত নেই। ফোনে অ্যাপটি ওপেন করে Pairing Key ইনপুট দিন।</td></tr>';
      return;
    }

    tbody.innerHTML = data.devices.map(d => `
      <tr>
        <td><code>${d.id}</code></td>
        <td><strong>${d.device_name}</strong></td>
        <td>${d.device_model}</td>
        <td><span class="badge badge-online">${d.status}</span></td>
        <td>${new Date(d.last_synced_at).toLocaleString()}</td>
        <td>🔋 ${d.battery_level || 100}%</td>
      </tr>
    `).join('');
  } catch (e) {
    console.error(e);
  }
}

async function handleCreateLink(e) {
  e.preventDefault();
  const amount = document.getElementById('createAmount').value;
  const customer_name = document.getElementById('createCustName').value;
  const customer_phone = document.getElementById('createCustPhone').value;

  try {
    const res = await fetch('/api/v1/checkout/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount, customer_name, customer_phone })
    });
    const data = await res.json();

    if (data.status) {
      const fullUrl = window.location.origin + data.payment_url;
      const resBox = document.getElementById('newLinkResult');
      resBox.style.display = 'block';
      document.getElementById('generatedUrlInput').value = fullUrl;
      document.getElementById('generatedUrlLink').href = fullUrl;
    }
  } catch (e) {
    alert('লিংক তৈরি করা যায়নি');
  }
}

function presetSim(type) {
  const sender = document.getElementById('simSender');
  const body = document.getElementById('simBody');
  const randomTrx = 'TRX' + Math.floor(100000 + Math.random() * 900000);

  if (type === 'bkash') {
    sender.value = 'bKash';
    body.value = `You have received Tk 500.00 from 01712345678. Fee Tk 0.00. Balance Tk 15,240.50. TrxID ${randomTrx} at 02/03/2026 14:32`;
  } else if (type === 'nagad') {
    sender.value = 'Nagad';
    body.value = `Money Received Amount: Tk 500.00 Sender: 01823456789 TxnID: ${randomTrx} Date: 2026-03-02 15:10:22`;
  } else if (type === 'rocket') {
    sender.value = '16216';
    body.value = `Tk 500.00 received from 019876543210 for A/C ... TxnId: ${randomTrx} Date: 2026-03-02 16:00`;
  }
}

async function handleSimulatorSubmit(e) {
  e.preventDefault();
  const sender = document.getElementById('simSender').value;
  const body = document.getElementById('simBody').value;
  const resBox = document.getElementById('simResult');

  try {
    const res = await fetch('/api/v1/reader/sync-sms', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sender, body, timestamp: new Date().toISOString() })
    });
    const result = await res.json();

    resBox.style.display = 'block';
    resBox.innerHTML = `
      <h4>সিমুলেশন রেসপন্স:</h4>
      <pre><code>${JSON.stringify(result, null, 2)}</code></pre>
    `;
    loadOverview();
  } catch (e) {
    alert('সিমুলেশন ব্যর্থ হয়েছে');
  }
}
