let currentInvoice = null;
let currentMethod = 'bkash';
let invoiceData = null;
let checkInterval = null;

document.addEventListener('DOMContentLoaded', async () => {
  feather.replace();

  const urlParams = new URLSearchParams(window.location.search);
  const invoiceId = urlParams.get('invoice') || 'INV-1002';

  await loadInvoice(invoiceId);
  setupTabs();
  setupTimer(20 * 60);

  document.getElementById('verifyForm').addEventListener('submit', handleVerifySubmit);
});

async function loadInvoice(id) {
  try {
    const res = await fetch(`/api/v1/checkout/${id}`);
    const data = await res.json();

    if (!data.status) {
      // If invoice not in DB, create demo on the fly
      const createRes = await fetch('/api/v1/checkout/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: 500, customer_name: 'ডেমো গ্রাহক', customer_phone: '01700000000' })
      });
      const createData = await createRes.json();
      currentInvoice = createData.invoice_id;
      return loadInvoice(currentInvoice);
    }

    invoiceData = data.data;
    currentInvoice = invoiceData.invoice_id;

    document.getElementById('invoiceDisplay').textContent = invoiceData.invoice_id;
    document.getElementById('totalAmount').textContent = `৳ ${invoiceData.total_amount.toFixed(2)}`;
    document.getElementById('customerBadge').textContent = `গ্রাহক: ${invoiceData.customer_name || 'সাধারণ গ্রাহক'}`;

    if (invoiceData.status === 'COMPLETED') {
      showSuccess(invoiceData);
      return;
    }

    renderInstruction(currentMethod);
    startPollingStatus();
  } catch (err) {
    console.error('Invoice load error:', err);
  }
}

function setupTabs() {
  const tabs = document.querySelectorAll('.method-tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      currentMethod = tab.dataset.method;
      renderInstruction(currentMethod);
    });
  });
}

function renderInstruction(method) {
  const container = document.getElementById('instructionContent');
  const methodObj = (invoiceData?.methods || []).find(m => m.id.toLowerCase() === method.toLowerCase()) || {
    name: method.toUpperCase(),
    number: '01700000000',
    type: 'personal'
  };

  const methodName = methodObj.name;
  const num = methodObj.number;
  const typeText = methodObj.type === 'merchant' ? 'মার্চেন্ট পেমেন্ট' : 'পার্সোনাল সেন্ড মানি';

  container.innerHTML = `
    <div class="step-row">
      <span class="step-num">১.</span> আপনার <strong>${methodName}</strong> অ্যাপ ওপেন করে <strong>${typeText}</strong> অপশনে যান।
    </div>
    <div class="step-row">
      <span class="step-num">২.</span> নিচের নম্বরে ঠিক <strong>৳ ${invoiceData ? invoiceData.total_amount.toFixed(2) : '500.00'}</strong> পাঠান:
      <div class="num-copy-container">
        <span class="mfs-number" id="targetNumber">${num}</span>
        <button class="btn-copy-num" onclick="copyNumber('${num}')">নম্বর কপি করুন</button>
      </div>
    </div>
    <div class="step-row">
      <span class="step-num">৩.</span> রেফারেন্সে আপনার ইনভয়েস নম্বর <code>${currentInvoice}</code> দিতে পারেন।
    </div>
    <div class="step-row">
      <span class="step-num">৪.</span> টাকা পাঠানোর পর এসএমএস থেকে <strong>Transaction ID (TrxID)</strong> টি নিচে লিখে সাবমিট করুন।
    </div>
  `;
}

function copyNumber(num) {
  navigator.clipboard.writeText(num);
  alert(`নম্বরটি (${num}) কপি করা হয়েছে!`);
}

function fillTestTrx(trx) {
  document.getElementById('trxIdInput').value = trx;
}

async function handleVerifySubmit(e) {
  e.preventDefault();
  const trxInput = document.getElementById('trxIdInput');
  const trx_id = trxInput.value.trim();
  const statusMsg = document.getElementById('statusMessage');

  if (!trx_id) return;

  statusMsg.className = 'status-msg info';
  statusMsg.textContent = 'পেমেন্ট ভেরিফাই করা হচ্ছে, অনুগ্রহ করে অপেক্ষা করুন...';

  try {
    const res = await fetch(`/api/v1/checkout/${currentInvoice}/verify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ trx_id, method: currentMethod })
    });
    const result = await res.json();

    if (result.verified || (result.transaction && result.transaction.status === 'COMPLETED')) {
      showSuccess(result.transaction);
    } else {
      statusMsg.className = 'status-msg info';
      statusMsg.textContent = 'আপনার TrxID গ্রহণ করা হয়েছে। রিডার অ্যাপ থেকে অটো ভেরিফিকেশন চলছে...';
    }
  } catch (err) {
    statusMsg.className = 'status-msg error';
    statusMsg.textContent = 'ভেরিফিকেশনে ত্রুটি দেখা দিয়েছে, আবার চেষ্টা করুন।';
  }
}

function startPollingStatus() {
  if (checkInterval) clearInterval(checkInterval);

  checkInterval = setInterval(async () => {
    try {
      const res = await fetch(`/api/v1/checkout/${currentInvoice}`);
      const data = await res.json();
      if (data.status && data.data.status === 'COMPLETED') {
        clearInterval(checkInterval);
        showSuccess(data.data);
      }
    } catch (e) {}
  }, 3000);
}

function showSuccess(tx) {
  if (checkInterval) clearInterval(checkInterval);
  document.querySelector('.amount-banner').style.display = 'none';
  document.querySelector('.methods-tab-header').style.display = 'none';
  document.querySelector('.instructions-panel').style.display = 'none';

  const screen = document.getElementById('successScreen');
  screen.style.display = 'block';

  document.getElementById('succInvoice').textContent = tx.invoice_id;
  document.getElementById('succTrx').textContent = tx.trx_id || 'VERIFIED';
  document.getElementById('succAmount').textContent = `৳ ${tx.total_amount.toFixed(2)}`;
  document.getElementById('succMethod').textContent = (tx.method || 'MFS').toUpperCase();

  feather.replace();
}

function setupTimer(duration) {
  let timer = duration;
  const display = document.getElementById('countdown');
  const timerInterval = setInterval(() => {
    const minutes = parseInt(timer / 60, 10);
    const seconds = parseInt(timer % 60, 10);

    display.textContent = `${minutes < 10 ? '0' + minutes : minutes}:${seconds < 10 ? '0' + seconds : seconds}`;

    if (--timer < 0) {
      clearInterval(timerInterval);
      display.textContent = "সময় শেষ";
    }
  }, 1000);
}
