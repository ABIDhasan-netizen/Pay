package com.paybd.reader.autopay_reader

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class SmsBroadcastReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION) {
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            for (sms in messages) {
                val sender = sms.displayOriginatingAddress ?: ""
                val messageBody = sms.displayMessageBody ?: ""
                Log.d("PayBDSmsReceiver", "SMS received from $sender: $messageBody")

                // Read server URL & pairing key saved in SharedPreferences
                val prefs = context.getSharedPreferences("PayBDReaderPrefs", Context.MODE_PRIVATE)
                val serverUrl = prefs.getString("server_url", "http://10.0.2.2:3000") ?: "http://10.0.2.2:3000"
                val deviceId = prefs.getString("device_id", "DEV-ANDROID") ?: "DEV-ANDROID"

                // Dispatch to server in background thread
                thread {
                    sendSmsToServer(serverUrl, deviceId, sender, messageBody)
                }
            }
        }
    }

    private fun sendSmsToServer(serverUrl: String, deviceId: String, sender: String, body: String) {
        try {
            val endpoint = if (serverUrl.endsWith("/")) "${serverUrl}api/v1/reader/sync-sms" else "$serverUrl/api/v1/reader/sync-sms"
            val url = URL(endpoint)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json; utf-8")
            conn.setRequestProperty("Accept", "application/json")
            conn.doOutput = true
            conn.connectTimeout = 8000
            conn.readTimeout = 8000

            val payload = JSONObject().apply {
                put("device_id", deviceId)
                put("sender", sender)
                put("body", body)
                put("timestamp", System.currentTimeMillis().toString())
            }

            OutputStreamWriter(conn.outputStream).use { writer ->
                writer.write(payload.toString())
                writer.flush()
            }

            val responseCode = conn.responseCode
            Log.d("PayBDSmsReceiver", "Server responded with code: $responseCode")
            conn.disconnect()
        } catch (e: Exception) {
            Log.e("PayBDSmsReceiver", "Failed to sync SMS to server: ${e.message}")
        }
    }
}
