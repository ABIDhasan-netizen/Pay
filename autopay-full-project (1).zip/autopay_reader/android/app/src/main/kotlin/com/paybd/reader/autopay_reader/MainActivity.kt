package com.paybd.reader.autopay_reader

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.paybd.reader/config"
    private val SMS_PERMISSION_CODE = 101

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "saveConfig" -> {
                    val serverUrl = call.argument<String>("server_url")
                    val deviceId = call.argument<String>("device_id")
                    val merchantEmail = call.argument<String>("merchant_email")
                    val deviceKey = call.argument<String>("device_key")
                    val prefs = getSharedPreferences("PayBDReaderPrefs", Context.MODE_PRIVATE)
                    prefs.edit()
                        .putString("server_url", serverUrl)
                        .putString("device_id", deviceId)
                        .putString("merchant_email", merchantEmail)
                        .putString("device_key", deviceKey)
                        .apply()
                    result.success(true)
                }
                "getConfig" -> {
                    val prefs = getSharedPreferences("PayBDReaderPrefs", Context.MODE_PRIVATE)
                    val map = mapOf(
                        "server_url" to (prefs.getString("server_url", "") ?: ""),
                        "device_id" to (prefs.getString("device_id", "") ?: ""),
                        "merchant_email" to (prefs.getString("merchant_email", "") ?: ""),
                        "device_key" to (prefs.getString("device_key", "") ?: "")
                    )
                    result.success(map)
                }
                "checkPermissions" -> {
                    val smsGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED &&
                                     ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
                    
                    val notifGranted = isNotificationServiceEnabled()
                    
                    var batteryIgnored = true
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                        batteryIgnored = pm.isIgnoringBatteryOptimizations(packageName)
                    }

                    result.success(mapOf(
                        "sms" to smsGranted,
                        "notification" to notifGranted,
                        "battery" to batteryIgnored
                    ))
                }
                "requestSmsPermission" -> {
                    ActivityCompat.requestPermissions(
                        this,
                        arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS),
                        SMS_PERMISSION_CODE
                    )
                    result.success(true)
                }
                "openNotificationSettings" -> {
                    try {
                        val intent = Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
                        startActivity(intent)
                        result.success(true)
                    } catch (e: Exception) {
                        result.error("ERROR", e.message, null)
                    }
                }
                "requestBatteryOptimization" -> {
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                data = Uri.parse("package:$packageName")
                            }
                            startActivity(intent)
                        }
                        result.success(true)
                    } catch (e: Exception) {
                        result.error("ERROR", e.message, null)
                    }
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun isNotificationServiceEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return flat != null && flat.contains(packageName)
    }
}
