package com.paybd.reader.autopay_reader

import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MfsNotificationListenerService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        val packageName = sbn.packageName ?: ""
        val extras = sbn.notification.extras
        val title = extras.getString("android.title") ?: ""
        val text = extras.getCharSequence("android.text")?.toString() ?: ""

        // Check if package or title is related to bKash, Nagad, Rocket, Upay
        val isMfs = packageName.contains("bkash", ignoreCase = true) ||
                    packageName.contains("nagad", ignoreCase = true) ||
                    packageName.contains("rocket", ignoreCase = true) ||
                    packageName.contains("upay", ignoreCase = true) ||
                    title.contains("bKash", ignoreCase = true) ||
                    title.contains("Nagad", ignoreCase = true) ||
                    title.contains("Rocket", ignoreCase = true)

        if (isMfs && text.isNotEmpty()) {
            Log.d("PayBDNotification", "MFS notification: [$title] $text")
            val prefs = getSharedPreferences("PayBDReaderPrefs", Context.MODE_PRIVATE)
            val serverUrl = prefs.getString("server_url", "http://10.0.2.2:3000") ?: "http://10.0.2.2:3000"
            val deviceId = prefs.getString("device_id", "DEV-ANDROID") ?: "DEV-ANDROID"

            thread {
                try {
                    val endpoint = if (serverUrl.endsWith("/")) "${serverUrl}api/v1/reader/sync-sms" else "$serverUrl/api/v1/reader/sync-sms"
                    val url = URL(endpoint)
                    val conn = url.openConnection() as HttpURLConnection
                    conn.requestMethod = "POST"
                    conn.setRequestProperty("Content-Type", "application/json; utf-8")
                    conn.doOutput = true
                    conn.connectTimeout = 8000
                    conn.readTimeout = 8000

                    val payload = JSONObject().apply {
                        put("device_id", deviceId)
                        put("sender", if (title.isNotEmpty()) title else packageName)
                        put("body", text)
                        put("timestamp", System.currentTimeMillis().toString())
                    }

                    OutputStreamWriter(conn.outputStream).use { writer ->
                        writer.write(payload.toString())
                        writer.flush()
                    }

                    conn.responseCode
                    conn.disconnect()
                } catch (e: Exception) {
                    Log.e("PayBDNotification", "Notification forward error: ${e.message}")
                }
            }
        }
    }
}
