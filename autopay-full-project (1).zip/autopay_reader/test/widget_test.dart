import 'package:flutter_test/flutter_test.dart';
import 'package:autopay_reader/main.dart';

void main() {
  testWidgets('PayBD Reader App initializes properly', (WidgetTester tester) async {
    await tester.pumpWidget(const PayBDReaderApp());
    expect(find.text('PayBD SMS Reader'), findsOneWidget);
    expect(find.text('মর্চেন্ট লগইন ও পেয়ারিং কনফিগারেশন'), findsOneWidget);
  });
}
