import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const PayBDReaderApp());
}

class PayBDReaderApp extends StatelessWidget {
  const PayBDReaderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PayBD Reader',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2563EB),
          primary: const Color(0xFF2563EB),
        ),
        useMaterial3: true,
      ),
      home: const ReaderHomeScreen(),
    );
  }
}

class ReaderHomeScreen extends StatefulWidget {
  const ReaderHomeScreen({super.key});

  @override
  State<ReaderHomeScreen> createState() => _ReaderHomeScreenState();
}

class _ReaderHomeScreenState extends State<ReaderHomeScreen> with WidgetsBindingObserver {
  static const platform = MethodChannel('com.paybd.reader/config');

  final TextEditingController _emailController =
      TextEditingController(text: 'admin@paybd.com');
  final TextEditingController _deviceKeyController =
      TextEditingController(text: 'READER-AUTO-9988');
  final TextEditingController _serverController =
      TextEditingController(text: 'http://10.0.2.2:3000');

  bool _isConnected = false;
  bool _isLoading = false;
  String _statusMessage = 'সার্ভারের সাথে কানেক্ট করুন';
  String _deviceId = 'Not Paired';

  // Permission states
  bool _smsPermission = false;
  bool _notifPermission = false;
  bool _batteryPermission = false;

  final List<Map<String, dynamic>> _logs = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadSavedConfig();
    _checkPermissions();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _checkPermissions();
    }
  }

  Future<void> _checkPermissions() async {
    try {
      final res = await platform.invokeMethod('checkPermissions');
      if (res is Map) {
        setState(() {
          _smsPermission = res['sms'] == true;
          _notifPermission = res['notification'] == true;
          _batteryPermission = res['battery'] == true;
        });
      }
    } catch (_) {}
  }

  Future<void> _requestSms() async {
    try {
      await platform.invokeMethod('requestSmsPermission');
    } catch (_) {}
    _checkPermissions();
  }

  Future<void> _requestNotification() async {
    try {
      await platform.invokeMethod('openNotificationSettings');
    } catch (_) {}
  }

  Future<void> _requestBattery() async {
    try {
      await platform.invokeMethod('requestBatteryOptimization');
    } catch (_) {}
  }

  Future<void> _loadSavedConfig() async {
    final prefs = await SharedPreferences.getInstance();
    final savedUrl = prefs.getString('server_url');
    final savedEmail = prefs.getString('merchant_email');
    final savedKey = prefs.getString('device_key');
    final savedDev = prefs.getString('device_id');

    if (savedUrl != null && savedUrl.isNotEmpty) {
      _serverController.text = savedUrl;
    }
    if (savedEmail != null && savedEmail.isNotEmpty) {
      _emailController.text = savedEmail;
    }
    if (savedKey != null && savedKey.isNotEmpty) {
      _deviceKeyController.text = savedKey;
    }
    if (savedDev != null && savedDev.isNotEmpty) {
      setState(() {
        _deviceId = savedDev;
        _isConnected = true;
        _statusMessage = 'সংযুক্ত আছে (Connected)';
      });
    }
  }

  Future<void> _pairWithServer() async {
    setState(() {
      _isLoading = true;
      _statusMessage = 'সার্ভারে কানেক্ট করা হচ্ছে...';
    });

    try {
      final url = _serverController.text.trim();
      final email = _emailController.text.trim();
      final key = _deviceKeyController.text.trim();

      if (url.isEmpty || key.isEmpty) {
        setState(() {
          _statusMessage = 'সার্ভার URL ও ডিভাইস কী পূরণ করুন!';
          _isLoading = false;
        });
        return;
      }

      final endpoint = url.endsWith('/') ? '${url}api/v1/reader/pair' : '$url/api/v1/reader/pair';

      final response = await http.post(
        Uri.parse(endpoint),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'email': email,
          'device_key': key,
          'pairing_key': key,
          'device_name': 'Android MFS Reader Phone',
          'device_model': 'Android Phone',
          'battery_level': 95,
        }),
      ).timeout(const Duration(seconds: 10));

      final data = jsonDecode(response.body);

      if (response.statusCode == 200 && data['status'] == true) {
        final devId = data['device_id'] ?? 'DEV-9988';
        setState(() {
          _isConnected = true;
          _deviceId = devId;
          _statusMessage = 'সফলভাবে পেয়ার সম্পন্ন হয়েছে!';
        });

        // Save preferences
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('server_url', url);
        await prefs.setString('merchant_email', email);
        await prefs.setString('device_key', key);
        await prefs.setString('device_id', devId);

        try {
          await platform.invokeMethod('saveConfig', {
            'server_url': url,
            'device_id': devId,
            'merchant_email': email,
            'device_key': key,
          });
        } catch (_) {}

        _addLog('সিস্টেম', 'ডিভাইস সফলভাবে পেয়ার হয়েছে: $devId', 'SUCCESS');
      } else {
        final errMsg = data['message'] ?? 'পেয়ারিং ব্যর্থ হয়েছে!';
        setState(() {
          _statusMessage = errMsg;
        });
        _addLog('ত্রুটি', 'পেয়ারিং ব্যর্থ: $errMsg', 'ERROR');
      }
    } catch (e) {
      setState(() {
        _statusMessage = 'সংযোগ ব্যর্থ: সার্ভার চালু আছে কিনা এবং URL সঠিক কিনা যাচাই করুন।';
      });
      _addLog('ত্রুটি', 'কানেকশন এরর: $e', 'ERROR');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _sendTestSms(String sender, String body) async {
    final url = _serverController.text.trim();
    final endpoint = url.endsWith('/') ? '${url}api/v1/reader/sync-sms' : '$url/api/v1/reader/sync-sms';

    _addLog(sender, 'মেসেজ পাঠানো হচ্ছে: $body', 'INFO');

    try {
      final response = await http.post(
        Uri.parse(endpoint),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'device_id': _deviceId,
          'sender': sender,
          'body': body,
          'timestamp': DateTime.now().toIso8601String(),
        }),
      ).timeout(const Duration(seconds: 10));

      final data = jsonDecode(response.body);
      if (data['status'] == true) {
        _addLog(sender, 'সার্ভার রেসপন্স: TrxID: ${data['trx_id'] ?? 'N/A'} (ম্যাচ: ${data['matched']})', 'SUCCESS');
      } else {
        _addLog(sender, 'রেসপন্স: ${data['message']}', 'WARNING');
      }
    } catch (e) {
      _addLog(sender, 'সিনক্রোনাইজেশনে ত্রুটি: $e', 'ERROR');
    }
  }

  void _addLog(String sender, String msg, String type) {
    setState(() {
      _logs.insert(0, {
        'time': TimeOfDay.now().format(context),
        'sender': sender,
        'message': msg,
        'type': type,
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: const Text('PayBD SMS Reader', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        backgroundColor: const Color(0xFF0F172A),
        foregroundColor: Colors.white,
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: _isConnected ? Colors.green.shade700 : Colors.red.shade700,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              children: [
                Icon(
                  _isConnected ? Icons.check_circle : Icons.error_outline,
                  size: 14,
                  color: Colors.white,
                ),
                const SizedBox(width: 4),
                Text(
                  _isConnected ? 'Online' : 'Offline',
                  style: const TextStyle(fontSize: 12, color: Colors.white, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          )
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Status Banner
            Card(
              elevation: 1,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              color: _isConnected ? const Color(0xFFF0FDF4) : const Color(0xFFFEF2F2),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: _isConnected ? Colors.green : Colors.red,
                      radius: 20,
                      child: Icon(
                        _isConnected ? Icons.sensors : Icons.sensors_off,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _isConnected ? 'রিডার সক্রিয় (Connected)' : 'রিডার নিষ্ক্রিয় (Disconnected)',
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            _statusMessage,
                            style: TextStyle(
                              fontSize: 12,
                              color: _isConnected ? Colors.green.shade900 : Colors.red.shade900,
                            ),
                          ),
                          if (_isConnected)
                            Padding(
                              padding: const EdgeInsets.only(top: 4),
                              child: Text(
                                'Device ID: $_deviceId',
                                style: const TextStyle(fontSize: 11, color: Colors.black54, fontWeight: FontWeight.w600),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),

            // 1. Permission status cards
            Card(
              elevation: 1,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'প্রয়োজনীয় পারমিশন (Permissions)',
                          style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                        ),
                        IconButton(
                          icon: const Icon(Icons.refresh, size: 20),
                          onPressed: _checkPermissions,
                          tooltip: 'পারমিশন রিফ্রেশ করুন',
                        )
                      ],
                    ),
                    const Text(
                      'অটো এসএমএস রিড করতে নিচের ৩টি অপশন চালু রাখা আবশ্যক:',
                      style: TextStyle(fontSize: 12, color: Colors.black54),
                    ),
                    const SizedBox(height: 10),

                    // SMS Permission Tile
                    _buildPermissionItem(
                      title: 'এসএমএস পারমিশন (SMS Permission)',
                      subtitle: 'ইনকামিং লেনদেন এসএমএস রিড করার জন্য',
                      isGranted: _smsPermission,
                      actionText: 'অনুমতি দিন',
                      onAction: _requestSms,
                    ),
                    const Divider(height: 16),

                    // Notification Listener Permission Tile
                    _buildPermissionItem(
                      title: 'নোটিফিকেশন পারমিশন (Notification)',
                      subtitle: 'বিকাশ ও নগদ অ্যাপ নোটিফিকেশন পড়ার জন্য',
                      isGranted: _notifPermission,
                      actionText: 'চালু করুন',
                      onAction: _requestNotification,
                    ),
                    const Divider(height: 16),

                    // Battery Optimization Permission Tile
                    _buildPermissionItem(
                      title: 'ব্যাকগ্রাউন্ড ব্যাটারি সেভার বন্ধ (Battery)',
                      subtitle: 'মোবাইল লক থাকলেও যাতে ব্যাকগ্রাউন্ডে কাজ করে',
                      isGranted: _batteryPermission,
                      actionText: 'সেটিংস',
                      onAction: _requestBattery,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),

            // 2. Merchant Authentication & Device Pairing Card
            Card(
              elevation: 1,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'মর্চেন্ট লগইন ও পেয়ারিং কনফিগারেশন',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'আপনার ওয়েবসাইট অ্যাডমিন প্যানেল থেকে প্রাপ্ত জিমেইল ও ডিভাইস কী দিন:',
                      style: TextStyle(fontSize: 12, color: Colors.black54),
                    ),
                    const SizedBox(height: 14),

                    // Gmail / Merchant Email Field
                    TextField(
                      controller: _emailController,
                      keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(
                        labelText: 'মর্চেন্ট ইমেইল (Merchant Gmail/Email)',
                        hintText: 'উদা: admin@paybd.com',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.email_outlined),
                        isDense: true,
                      ),
                    ),
                    const SizedBox(height: 12),

                    // Device Key Field
                    TextField(
                      controller: _deviceKeyController,
                      decoration: const InputDecoration(
                        labelText: 'ডিভাইস কী (Device Key / Pairing Key)',
                        hintText: 'উদা: READER-AUTO-9988',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.vpn_key_outlined),
                        isDense: true,
                      ),
                    ),
                    const SizedBox(height: 12),

                    // Server URL Field
                    TextField(
                      controller: _serverController,
                      decoration: const InputDecoration(
                        labelText: 'সার্ভার URL (Website Server Domain/IP)',
                        hintText: 'https://yourdomain.com অথবা http://IP:PORT',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.link),
                        isDense: true,
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Connect Button
                    ElevatedButton.icon(
                      onPressed: _isLoading ? null : _pairWithServer,
                      icon: _isLoading
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                            )
                          : const Icon(Icons.sync),
                      label: Text(
                        _isLoading ? 'কানেক্ট করা হচ্ছে...' : 'সার্ভারের সাথে কানেক্ট করুন',
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF2563EB),
                        foregroundColor: Colors.white,
                        minimumSize: const Size.fromHeight(46),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),

            // 3. Test Simulation Tool
            Card(
              elevation: 1,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'টেস্ট SMS টুল (সিম কার্ড ছাড়া চেক করুন)',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'সার্ভারে টেস্ট এসএমএস পাঠিয়ে কানেকশন এবং অটো-ভেরিফিকেশন চেক করুন:',
                      style: TextStyle(fontSize: 12, color: Colors.black54),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () {
                              final randomTrx = 'BK${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}';
                              _sendTestSms(
                                'bKash',
                                'You have received Tk 500.00 from 01712345678. Fee Tk 0.00. Balance Tk 15,240.50. TrxID $randomTrx at 02/03/2026 14:32',
                              );
                            },
                            style: OutlinedButton.styleFrom(
                              foregroundColor: const Color(0xFFE2136E),
                              side: const BorderSide(color: Color(0xFFE2136E)),
                            ),
                            child: const Text('বিকাশ টেস্ট SMS'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () {
                              final randomTrx = 'NG${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}';
                              _sendTestSms(
                                'Nagad',
                                'Money Received Amount: Tk 500.00 Sender: 01823456789 TxnID: $randomTrx Date: 2026-03-02 15:10:22',
                              );
                            },
                            style: OutlinedButton.styleFrom(
                              foregroundColor: const Color(0xFFF7941D),
                              side: const BorderSide(color: Color(0xFFF7941D)),
                            ),
                            child: const Text('নগদ টেস্ট SMS'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),

            // 4. Live Activity Log
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 4, vertical: 4),
              child: Text(
                'লাইভ অ্যাক্টিভিটি লগ (Live Reader Logs)',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
              ),
            ),
            _logs.isEmpty
                ? const Card(
                    child: Padding(
                      padding: EdgeInsets.all(20.0),
                      child: Center(
                        child: Text(
                          'এখনও কোনো ট্রানজেকশন লগ তৈরি হয়নি',
                          style: TextStyle(color: Colors.grey, fontSize: 13),
                        ),
                      ),
                    ),
                  )
                : ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _logs.length,
                    itemBuilder: (context, index) {
                      final log = _logs[index];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 6),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        child: ListTile(
                          dense: true,
                          leading: Text(
                            log['time'] ?? '',
                            style: const TextStyle(fontSize: 11, color: Colors.grey),
                          ),
                          title: Text(
                            log['sender'] ?? '',
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                          ),
                          subtitle: Text(
                            log['message'] ?? '',
                            style: const TextStyle(fontSize: 12),
                          ),
                        ),
                      );
                    },
                  ),
          ],
        ),
      ),
    );
  }

  Widget _buildPermissionItem({
    required String title,
    required String subtitle,
    required bool isGranted,
    required String actionText,
    required VoidCallback onAction,
  }) {
    return Row(
      children: [
        Icon(
          isGranted ? Icons.check_circle : Icons.warning_amber_rounded,
          color: isGranted ? Colors.green : Colors.orange.shade800,
          size: 24,
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
              ),
              Text(
                subtitle,
                style: const TextStyle(fontSize: 11, color: Colors.black54),
              ),
            ],
          ),
        ),
        const SizedBox(width: 8),
        if (isGranted)
          const Chip(
            label: Text('সক্রিয়', style: TextStyle(color: Colors.green, fontSize: 11)),
            backgroundColor: Color(0xFFDCFCE7),
            padding: EdgeInsets.zero,
            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
          )
        else
          ElevatedButton(
            onPressed: onAction,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF2563EB),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
              minimumSize: const Size(60, 32),
              textStyle: const TextStyle(fontSize: 11),
            ),
            child: Text(actionText),
          ),
      ],
    );
  }
}
